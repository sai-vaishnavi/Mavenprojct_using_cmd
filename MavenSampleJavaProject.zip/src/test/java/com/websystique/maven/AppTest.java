package com.websystique.maven;

import static org.fest.assertions.Assertions.assertThat;

import org.testng.annotations.Test;
/**
 * Unit test for simple App.
 */
public class AppTest{ 

	
	App app = new App();

	@Test
	public void testSum(){
		int expected = 30;
		int actual = app.sum(10, 20);
		assertThat(actual).isEqualTo(expected);
	}

}